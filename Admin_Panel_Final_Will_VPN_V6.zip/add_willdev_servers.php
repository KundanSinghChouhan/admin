<p>
    <title>Plugin Installation</title>
</p>
<style>
    body {
        text-align: center;
        padding: 150px;
    }

    h1 {
        font-size: 50px;
    }

    body {
        font: 20px Helvetica, sans-serif;
        color: #333;
    }

    article {
        display: block;
        text-align: left;
        width: 650px;
        margin: 0 auto;
    }

    a {
        color: #dc8100;
        text-decoration: none;
    }

    a:hover {
        color: #333;
        text-decoration: none;
    }
</style>
<article>
    <h2>Dear Client, For Active Open Server Plugin, You need to contact us to Get Plugin in Free, Or you can Create Support Ticket.</h2>
    <div>
        <p><strong>Note :-</strong> If you Only Want to Use <a href="https://developer.oneconnect.top/packages/">OneConnect.top</a> Server Only, Then Not Required to use this Plugin, For More Information Please create a Support Ticket, So Our Team will Help You. <a href="https://help.willdev.in/" rel="noopener noreferrer" target="_blank">https://help.willdev.in/</a></p>&mdash; The Team <a href="https://codecanyon.net/user/will_dev" rel="noopener noreferrer" target="_blank">Will_Dev</a>
        <p>&mdash; Back to Panel <a href="../home.php" rel="noopener noreferrer" target="_blank">Back to Panel</a></p>
    </div>
</article>