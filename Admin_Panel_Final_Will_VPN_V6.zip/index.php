<p>
    <title>Will VPN Installation</title>
</p>
<style>
    body {
        text-align: center;
        padding: 150px;
    }

    h1 {
        font-size: 50px;
    }

    body {
        font: 20px Helvetica, sans-serif;
        color: #333;
    }

    article {
        display: block;
        text-align: left;
        width: 650px;
        margin: 0 auto;
    }

    a {
        color: #dc8100;
        text-decoration: none;
    }

    a:hover {
        color: #333;
        text-decoration: none;
    }
</style>
<article>
    <h2>Dear Client For installing the Will_Dev Script | Just Click on <a href="/install/"><strong><u>Installation Click</u></strong></a></h2>
    <div>
        <p>Before Click on Installation, Make Sure you have Read the Documentation, Inside Documentation All Steps is already mentoined, So, kindly Follow that, Or If you are getting any issue in Setup, Please Create Support Ticket, So Our Team will Help You. <a href="https://help.willdev.in/" rel="noopener noreferrer" target="_blank">https://help.willdev.in/</a></p>&mdash; The Team <a href="https://codecanyon.net/user/will_dev" rel="noopener noreferrer" target="_blank">Will_Dev</a>
        <p><br></p>
    </div>
</article>